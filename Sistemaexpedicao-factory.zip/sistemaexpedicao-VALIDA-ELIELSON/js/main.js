import { getState, setState } from './state.js';
import { loadUserPermissions, hasPermission } from './auth.js';
import { supabaseRequest } from './api.js';
import { showNotification } from './ui.js';

// Variáveis para timers e instâncias globais necessárias que ainda não forão migradas
window.activeTimers = {};
window.rastreioTimer = null;
window.homeMapTimer = null;

import * as faturamentoModule from './modules/faturamento.js';
import * as motoristasModule from './modules/motoristas.js';
import * as operacaoModule from './modules/operacao.js';
import * as historicoModule from './modules/historico.js';
import * as acompanhamentoModule from './modules/acompanhamento.js';
import * as configuracoesModule from './modules/configuracoes.js';
import * as homeModule from './modules/home.js';

// Anexando transporte e home
import * as transporteModule from './modules/transporte.js';
window.loadTransportList = transporteModule.loadTransportList;
window.lancarCarga = transporteModule.lancarCarga;
window.agruparEAlocar = transporteModule.agruparEAlocar;
window.atualizarResumoAgrupamento = transporteModule.atualizarResumoAgrupamento;

// Função para exibir a View correta
window.showView = function (viewId, element) {
    if (!element) return;

    const permission = element.dataset.permission;

    let checkPermission = permission;
    if (permission && permission.startsWith('acesso_')) {
        checkPermission = permission;
    } else if (permission) {
        const mappedPermission = permission.replace('acesso_', 'view_');
        if (!hasPermission(permission) && hasPermission(mappedPermission)) {
            checkPermission = mappedPermission;
        } else {
            checkPermission = permission;
        }
    }

    if (checkPermission && !hasPermission(checkPermission)) {
        const alternativePermission = checkPermission.startsWith('acesso_') ?
            checkPermission.replace('acesso_', 'view_') :
            checkPermission;

        if (checkPermission !== alternativePermission && hasPermission(alternativePermission)) {
            // Pass Permitido
        } else {
            showNotification('Você não tem permissão para acessar esta aba.', 'error');
            return;
        }
    }

    document.querySelectorAll('.view-content').forEach(view => view.classList.remove('active'));

    const viewElement = document.getElementById(viewId);
    if (viewElement) viewElement.classList.add('active');

    document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));
    if (element) element.classList.add('active');

    Object.values(window.activeTimers).forEach(clearInterval);
    window.activeTimers = {};

    if (window.rastreioTimer) {
        clearInterval(window.rastreioTimer);
        window.rastreioTimer = null;
    }

    if (window.homeMapTimer) {
        clearInterval(window.homeMapTimer);
        window.homeMapTimer = null;
    }

    // Carregamento Lazy - Aqui futuramente chamaremos import()'s
    switch (viewId) {
        case 'home':
            if (window.loadHomeData) window.loadHomeData();
            break;
        case 'transporte':
            console.log('TODO: loadTransportList()');
            break;
        case 'faturamento':
            console.log('TODO: loadFaturamento()');
            break;
        case 'motoristas':
            console.log('TODO: loadMotoristaTab()');
            break;
        case 'acompanhamento':
            if (window.loadAcompanhamento) window.loadAcompanhamento();
            break;
        case 'historico':
            console.log('TODO: loadHistorico()');
            break;
        case 'configuracoes':
            if (window.loadConfiguracoes) window.loadConfiguracoes();
            break;
        case 'operacao':
            console.log('TODO: loadOperacao()');
            break;
    }

    if (window.feather) window.feather.replace();
};

window.trocarFilial = function () {
    document.getElementById('mainSystem').style.display = 'none';
    document.getElementById('filialSelectionContainer').style.display = 'block';
    // Oculta mapas se existirem
    const mapEl = document.getElementById('map');
    const homeMapEl = document.getElementById('homeMapFullscreenDialog');
    if (mapEl) mapEl.style.display = 'none';
    if (homeMapEl) homeMapEl.style.display = 'none';
};

window.forceRefresh = function () {
    const activeView = document.querySelector('.view-content.active');
    if (activeView) {
        showNotification('Atualizando dados...', 'info', 1500);
        showView(activeView.id, document.querySelector(`.nav-item[href="#${activeView.id}"]`));
    }
};

window.logOut = function () {
    setState('selectedFilial', null);
    setState('userId', null);
    setState('userName', null);
    setState('userPermissions', []);
    setState('masterUserPermission', false);

    document.getElementById('mainSystem').style.display = 'none';
    document.getElementById('filialSelectionContainer').style.display = 'none';
    document.getElementById('initialAuthContainer').style.display = 'block';

    const loginForm = document.getElementById('initialLoginForm');
    if (loginForm) loginForm.reset();

    localStorage.removeItem('jp_expedicao_user');

    Object.values(window.activeTimers).forEach(clearInterval);
};

// Bootstrap - Inicialização da aplicação
document.addEventListener('DOMContentLoaded', () => {
    // Registra Feather Icons se existir
    if (window.feather) window.feather.replace();

    // Configura listeners de login usando o UI
    const loginForm = document.getElementById('initialLoginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            // TODO: Migrar a lógica brutal de auth aqui... (simulação no próximo step)
            console.log('Login mock disparado para migração na próxima fase.');
        });
    }
});
